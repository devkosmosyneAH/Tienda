Future<void> initializeDatabasePlatform() async {}
