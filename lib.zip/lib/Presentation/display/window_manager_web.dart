Future<void> initializeWindowManager() async {}
